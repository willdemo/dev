<?php
$_ENV["user"] = "root";
$_ENV["password"] = "";
$_ENV["host"] = "localhost";
$_ENV["db"] = "tester";
